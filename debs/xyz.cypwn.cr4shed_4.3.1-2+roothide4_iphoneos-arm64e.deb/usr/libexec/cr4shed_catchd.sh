#!/bin/sh
# cr4shed_catchd launcher.
# RootHide's launchd resolves the registered binary's bare path (e.g.
# /usr/libexec/...) against the jbroot, while the real rootfs is exposed at
# /rootfs. python3 and the converter script may live in either view depending
# on how they were installed, so this wrapper locates BOTH in any namespace
# view and execs the converter. Invoked by launchd as a single bare path
# (mirrors how com.muirey03.cr4shedd runs /usr/libexec/cr4shedd).
set -e

SCRIPT_CANDIDATES="
/var/jb/usr/libexec/cr4shed_catchd.py
/usr/libexec/cr4shed_catchd.py
/rootfs/var/jb/usr/libexec/cr4shed_catchd.py
/rootfs/usr/libexec/cr4shed_catchd.py
"
PY_CANDIDATES="
/var/jb/usr/bin/python3
/usr/bin/python3
/rootfs/var/jb/usr/bin/python3
/rootfs/usr/bin/python3
"

script=""
for s in $SCRIPT_CANDIDATES; do
    [ -r "$s" ] && script="$s" && break
done

if [ -z "$script" ]; then
    echo "cr4shed_catchd: converter script not found in any namespace view" >&2
    exit 0
fi

for p in $PY_CANDIDATES; do
    if [ -x "$p" ]; then
        exec "$p" "$script"
    fi
done

# last resort: whatever python3 is on PATH
if command -v python3 >/dev/null 2>&1; then
    exec python3 "$script"
fi

echo "cr4shed_catchd: python3 not found anywhere; install a python3 package" >&2
exit 0
