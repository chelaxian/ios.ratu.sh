#!/usr/bin/env python3
"""
cr4shed_catchd - iOS 17 crash catcher for Cr4shed (file-watch approach).

ROOT CAUSE this replaces: Cr4shed's original pipeline (0Cr4shed.dylib ->
cr4shedd via NSConnection/Distributed Objects) is broken on iOS 17 because
NSConnection is deprecated/removed, and Cr4shedMach.dylib can't inject into
ReportCrash (platform binary). This daemon sidesteps both by reading the .ips
files that ReportCrash writes to ~/Library/Logs/CrashReporter/ and converting
them into Cr4shed-style .log files into ~/Library/Cr4shed/.

Run via launchd (StartInterval). Each invocation is a one-shot scan. Designed
to run as root (LaunchDaemon) so it can read root-owned .ips files. Output
files are chmod 0666 so the mobile-user Cr4shed GUI can read them regardless
of namespace. Writes to BOTH the jbroot view and the real-rootfs view of
/var/mobile/Library/Cr4shed so the GUI sees the logs no matter which
namespace it resolves the path in.
"""
import os, sys, json, glob, time, re

# .ips source: on RootHide the real CrashReporter dir lives behind /rootfs.
# Check several candidate views; empty ones are harmless.
CRASH_DIRS = [
    "/rootfs/private/var/mobile/Library/Logs/CrashReporter",
    "/rootfs/var/mobile/Library/Logs/CrashReporter",
    "/var/mobile/Library/Logs/CrashReporter",
    "/private/var/mobile/Library/Logs/CrashReporter",
]
# Output: write to every creatable view so the GUI finds logs regardless of
# whether it resolves /var/mobile/... against the jbroot or the real rootfs.
OUT_DIRS = [
    "/var/mobile/Library/Cr4shed",
    "/rootfs/private/var/mobile/Library/Cr4shed",
    "/rootfs/var/mobile/Library/Cr4shed",
    "/private/var/mobile/Library/Cr4shed",
]
SEEN_MARKER = ".catchd_processed"


def read_ips(path):
    """Return (header_dict, body_dict) or (None, None) on failure."""
    try:
        with open(path, "r", errors="replace") as f:
            raw = f.read()
        parts = raw.split("\n", 1)
        header = json.loads(parts[0]) if parts[0].strip() else {}
        body = json.loads(parts[1]) if len(parts) > 1 and parts[1].strip() else {}
        return header, body
    except Exception:
        return None, None


def safe_name(s):
    if not s:
        return "Unknown"
    return re.sub(r'[^A-Za-z0-9_.-]', '_', str(s))[:80]


def get_image_name(used_images, idx):
    try:
        return used_images[idx].get("name", "?")
    except (IndexError, TypeError):
        return "?"


def format_backtrace(body, max_frames=25):
    threads = body.get("threads", [])
    fault_idx = body.get("faultingThread", -1)
    used = body.get("usedImages", [])
    if fault_idx < 0 or fault_idx >= len(threads):
        return "(no faulting thread data)"
    frames = threads[fault_idx].get("frames", [])
    lines = []
    for i, fr in enumerate(frames[:max_frames]):
        img_idx = fr.get("imageIndex", -1)
        img_name = get_image_name(used, img_idx)
        offset = fr.get("imageOffset", 0)
        sym = fr.get("symbol", "")
        sym_loc = fr.get("symbolLocation", "")
        if sym:
            loc = f"{sym} + {sym_loc}" if sym_loc else sym
            lines.append(f"  {i}: {img_name}  {loc}  (0x{offset:x})")
        else:
            lines.append(f"  {i}: {img_name}  0x{offset:x}")
    return "\n".join(lines) if lines else "(empty backtrace)"


def format_log(path):
    header, body = read_ips(path)
    if header is None:
        return None, None

    app_name = header.get("app_name") or body.get("procName") or "Unknown"
    ts = header.get("timestamp", time.strftime("%Y-%m-%d %H:%M:%S"))
    incident = header.get("incident_id", "")
    bug_type = header.get("bug_type", "")
    os_ver = header.get("os_version", "")

    proc_name = body.get("procName", app_name)
    proc_path = body.get("procPath", "")
    pid_val = body.get("pid", "")

    term = body.get("termination", {}) or {}
    exc = body.get("exception", {}) or {}
    if not isinstance(term, dict):
        term = {}
    if not isinstance(exc, dict):
        exc = {}

    term_ns = term.get("namespace", "")
    term_code = term.get("code", "")
    term_ind = term.get("indicator", "")
    term_det = term.get("details", [])
    if not isinstance(term_det, list):
        term_det = []

    exc_type = exc.get("type", "")
    exc_signal = exc.get("signal", "")
    exc_subtype = exc.get("subtype", "")
    exc_codes = exc.get("codes", [])
    if not isinstance(exc_codes, list):
        exc_codes = []

    asi = body.get("asi", "") or body.get("asiBacktraces", "")

    bt = format_backtrace(body)

    lines = []
    lines.append(f"Date: {ts}")
    lines.append(f"Process: {proc_name}")
    lines.append(f"Bundle id: {body.get('bundleID', '')}")
    lines.append(f"OS Version: {os_ver}")
    if proc_path:
        lines.append(f"Path: {proc_path}")
    if pid_val != "":
        lines.append(f"PID: {pid_val}")
    if incident:
        lines.append(f"Incident ID: {incident}")
    if bug_type:
        lines.append(f"Bug Type: {bug_type}")
    lines.append("")
    lines.append(f"Exception Type: {exc_type}" + (f" ({exc_signal})" if exc_signal else ""))
    if exc_subtype:
        lines.append(f"Exception Subtype: {exc_subtype}")
    if exc_codes:
        lines.append(f"Exception Codes: {', '.join(str(c) for c in exc_codes)}")
    lines.append(f"Termination: {term_ns}" + (f", Code {term_code}" if term_code != "" else "") + (f", {term_ind}" if term_ind else ""))
    if term_det:
        for d in term_det:
            lines.append(f"  {d}")
    lines.append("")
    if asi:
        lines.append("Application Specific Information:")
        lines.append(str(asi))
        lines.append("")
    lines.append("Backtrace (faulting thread):")
    lines.append(bt)
    lines.append("")
    lines.append(f"(Parsed from {os.path.basename(path)} by cr4shed_catchd)")
    return "\n".join(lines), safe_name(proc_name) + "_" + re.sub(r'[^0-9]', '', ts)[:14]


def ensure_out_dirs():
    """Create + open every OUT_DIR we can; return the list of usable ones."""
    usable = []
    for d in OUT_DIRS:
        try:
            os.makedirs(d, exist_ok=True)
            # ensure mobile can traverse/read: 0777 on the dir
            os.chmod(d, 0o777)
            usable.append(d)
        except OSError:
            pass
    # de-dup by realpath (jbroot and rootfs views may be the same inode)
    seen = set()
    uniq = []
    for d in usable:
        rp = os.path.realpath(d)
        if rp not in seen:
            seen.add(rp)
            uniq.append(d)
    return uniq


def load_processed(out_dirs):
    for d in out_dirs:
        try:
            with open(os.path.join(d, SEEN_MARKER), "r") as f:
                return set(line.strip() for line in f if line.strip())
        except IOError:
            continue
    return set()


def main():
    out_dirs = ensure_out_dirs()
    crash_dirs = [d for d in CRASH_DIRS if os.path.isdir(d)]
    if not crash_dirs or not out_dirs:
        return 0

    processed = load_processed(out_dirs)
    new_processed = []
    count = 0
    seen_paths = set()
    for d in crash_dirs:
        for ips in sorted(glob.glob(os.path.join(d, "*.ips"))):
            rp = os.path.realpath(ips)
            if rp in seen_paths:
                continue
            seen_paths.add(rp)
            base = os.path.basename(ips)
            if base.startswith("JetsamEvent"):
                continue
            if base in processed:
                continue
            try:
                log_text, log_name = format_log(ips)
            except Exception:
                log_text, log_name = None, None
            if log_text is None:
                new_processed.append(base)
                continue
            # write to every usable OUT_DIR
            for od in out_dirs:
                out = os.path.join(od, log_name + ".log")
                i = 1
                while os.path.exists(out):
                    out = os.path.join(od, f"{log_name}_{i}.log")
                    i += 1
                try:
                    with open(out, "w") as f:
                        f.write(log_text)
                    os.chmod(out, 0o666)
                except IOError:
                    pass
            count += 1
            new_processed.append(base)

    if new_processed:
        all_p = processed.union(new_processed)
        for od in out_dirs:
            try:
                with open(os.path.join(od, SEEN_MARKER), "w") as f:
                    for b in sorted(all_p)[-500:]:
                        f.write(b + "\n")
            except IOError:
                pass

    if count:
        print(f"cr4shed_catchd: wrote {count} new log(s) to {out_dirs}", file=sys.stderr)
    return 0


if __name__ == "__main__":
    sys.exit(main())
