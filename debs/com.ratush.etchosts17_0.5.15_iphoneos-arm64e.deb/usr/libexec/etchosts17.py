#!/usr/bin/env python3
"""EtcHosts17 local DNS override daemon.

Architecture (iOS 17 RootHide, APFS sealed system volume):
  The real /etc/hosts lives on the sealed (SSV) system volume and can never be
  edited, and mDNSResponder is a non-injectable platform binary. The only DNS
  override mechanism that is visible and enforceable in Settings on this device
  is an installed configuration profile (com.apple.dnsSettings.managed), exactly
  like the NextDNS/AdGuard encrypted-DNS profiles already present.

  So this daemon is a small local resolver that also speaks DNS-over-TLS (DoT)
  on port 853, presenting a certificate signed by a per-device CA. A generated
  .mobileconfig bundles that CA (as a trusted root payload) plus a scoped DoT
  DNS payload whose SupplementalMatchDomains list exactly the overridden hosts.
  Once the profile is installed, iOS routes only those names to this daemon over
  DoT -- winning over encrypted DoH profiles (ControlD) and VPN DNS -- and every
  other name keeps its normal path. That is the /etc/hosts parity we want.

  The daemon serves the freshly-generated .mobileconfig over a localhost HTTP
  port so the Settings bundle can hand the user straight into the install sheet.

Persistence rule: this daemon is READ-ONLY with respect to
com.ratush.etchosts17.plist. Only the Settings bundle writes that file
(presets, toggles, HostsText). The daemon reads it and only writes runtime
caches (daemon.hosts, hosts.merged). This keeps custom presets and toggles from
being collapsed/reset on respring or reinstall.
"""
import argparse
import base64
import ipaddress
import os
import plistlib
import re
import select
import socket
import ssl
import struct
import sys
import threading
import time
import uuid
from http.server import BaseHTTPRequestHandler, ThreadingHTTPServer


ROOTFS_DIR = "/rootfs/private/var/mobile/Library/EtcHosts17"
JBROOT_DIR = "/var/mobile/Library/EtcHosts17"
ROOTFS_MERGED = ROOTFS_DIR + "/hosts.merged"
JBROOT_MERGED = JBROOT_DIR + "/hosts.merged"
ROOTFS_PREFS = "/rootfs/private/var/mobile/Library/Preferences/com.ratush.etchosts17.plist"
JBROOT_PREFS = "/var/mobile/Library/Preferences/com.ratush.etchosts17.plist"
DAEMON_HOSTS = JBROOT_DIR + "/daemon.hosts"
UPSTREAMS_FILE = JBROOT_DIR + "/upstreams"
BASE_HOSTS = "/etc/hosts"

TLS_DIR = JBROOT_DIR + "/tls"
CA_DER = TLS_DIR + "/ca.der"
SERVER_CERT = TLS_DIR + "/server.pem"
SERVER_KEY = TLS_DIR + "/server.key"

PREFS_HOSTS_KEY = "HostsText"
PREFS_ENABLED_KEY = "Enabled"
PREFS_GLOBAL_KEY = "GlobalMode"
PREFS_FALLBACK_KEY = "FallbackSystemDNS"
PREFS_CREATE_PROFILE_KEY = "CreateDNSProfile"
PREFS_SELECTED_PRESET_KEY = "SelectedPreset"

CONTROL_MAGIC = b"ETCHOSTS17\n"
CONTROL_APPLY_MAGIC = b"ETCHOSTS17APPLY\n"
CONTROL_PORT = 53535
DOT_PORT = 853
PROFILE_HTTP_PORT = 53580
PROFILE_SERVER_NAME = "etchosts17.local"
PROFILE_ID = "com.ratush.etchosts17.dns"
PROFILE_FILENAME = "EtcHosts17.mobileconfig"

DEFAULT_EXTRA = (
    "# EtcHosts17 supplemental entries\n"
    "127.0.0.1 localhost\n"
    "# Examples:\n"
    "# 0.0.0.0 example.com other.example.com\n"
    "# ::1 ipv6.example.com\n"
)
UPSTREAMS = ["9.9.9.9", "1.1.1.1", "8.8.8.8"]


def read_upstreams():
    """Real resolvers captured by etchosts17resolv (the VPN's own DNS included),
    so forwarding non-overridden queries works under a VPN. Falls back to the
    public defaults if nothing was captured yet."""
    try:
        with open(UPSTREAMS_FILE, "r", encoding="utf-8", errors="ignore") as handle:
            servers = [line.strip() for line in handle if line.strip()]
        servers = [s for s in servers if not s.startswith("127.") and s not in ("::1", "0.0.0.0")]
        # Keep the public defaults as a last-resort tail so DNS never dead-ends.
        for d in UPSTREAMS:
            if d not in servers:
                servers.append(d)
        return servers or UPSTREAMS
    except OSError:
        return UPSTREAMS

IPV4_RE = re.compile(r"^[0-9]{1,3}(\.[0-9]{1,3}){3}$")
DOMAIN_RE = re.compile(
    r"^[A-Za-z0-9_]([A-Za-z0-9_-]{0,61}[A-Za-z0-9_])?"
    r"(\.[A-Za-z0-9_]([A-Za-z0-9_-]{0,61}[A-Za-z0-9_])?)*\.?$"
)


def log(message):
    sys.stderr.write(time.strftime("%Y-%m-%d %H:%M:%S ") + message + "\n")
    sys.stderr.flush()


def ensure_storage():
    for path in (ROOTFS_DIR, JBROOT_DIR):
        try:
            os.makedirs(path, exist_ok=True)
            os.chmod(path, 0o755)
        except OSError:
            pass


def read_text(path):
    with open(path, "r", encoding="utf-8", errors="ignore") as handle:
        return handle.read()


def write_text(path, text, mode=0o644):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as handle:
        handle.write(text)
    if path.startswith("/var/mobile/") or path.startswith("/rootfs/private/var/mobile/"):
        try:
            os.chown(tmp, 501, 501)
        except OSError:
            pass
    os.chmod(tmp, mode)
    os.replace(tmp, path)


def read_plist_dict(path):
    with open(path, "rb") as handle:
        value = plistlib.load(handle)
    return value if isinstance(value, dict) else {}


def newest_prefs_path():
    existing = [p for p in (ROOTFS_PREFS, JBROOT_PREFS) if os.path.exists(p)]
    if not existing:
        return None
    return max(existing, key=lambda p: os.stat(p).st_mtime)


def read_settings():
    settings = {
        PREFS_ENABLED_KEY: True,
        PREFS_GLOBAL_KEY: False,
        PREFS_FALLBACK_KEY: True,
        PREFS_CREATE_PROFILE_KEY: False,
    }
    path = newest_prefs_path()
    if path:
        try:
            prefs = read_plist_dict(path)
            for key in list(settings.keys()):
                if isinstance(prefs.get(key), bool):
                    settings[key] = prefs[key]
        except Exception as exc:
            log("cannot read settings: %s" % exc)
    return settings


def read_hosts_text():
    """Read the active hosts text, preferring the newest source. Read-only."""
    candidates = []
    for path in (ROOTFS_PREFS, JBROOT_PREFS):
        if os.path.exists(path):
            candidates.append((os.stat(path).st_mtime, path, "plist"))
    if os.path.exists(DAEMON_HOSTS):
        candidates.append((os.stat(DAEMON_HOSTS).st_mtime, DAEMON_HOSTS, "text"))
    if not candidates:
        return DEFAULT_EXTRA
    _mtime, path, kind = max(candidates)
    try:
        if kind == "plist":
            value = read_plist_dict(path).get(PREFS_HOSTS_KEY)
            return value if isinstance(value, str) and value.strip() else DEFAULT_EXTRA
        return read_text(path)
    except Exception as exc:
        log("cannot read hosts from %s: %s" % (path, exc))
        return DEFAULT_EXTRA


def normalize_hosts_text(text):
    value = (text or "").replace("\r\n", "\n").replace("\r", "\n")
    if value and not value.endswith("\n"):
        value += "\n"
    return value


def valid_ip_literal(value):
    if "." in value and ":" not in value and not IPV4_RE.match(value):
        return False
    try:
        ipaddress.ip_address(value)
        return True
    except ValueError:
        return False


def validation_errors(text):
    errors = []
    for index, raw_line in enumerate(normalize_hosts_text(text).splitlines(), start=1):
        line = raw_line.split("#", 1)[0].strip()
        if not line:
            continue
        parts = line.split()
        if len(parts) < 2:
            errors.append("line %d: use 'IP hostname [hostname ...]'" % index)
            continue
        if not valid_ip_literal(parts[0]):
            errors.append("line %d: invalid IP address %r" % (index, parts[0]))
            continue
        for domain in parts[1:]:
            if not DOMAIN_RE.match(domain):
                errors.append("line %d: invalid hostname %r" % (index, domain))
    return errors


def validated_hosts_text(text):
    value = normalize_hosts_text(text)
    errors = validation_errors(value)
    if errors:
        raise ValueError("; ".join(errors))
    return value


def parse_hosts_text(text):
    hosts = {}
    for raw_line in normalize_hosts_text(text).splitlines():
        line = raw_line.split("#", 1)[0].strip()
        if not line:
            continue
        parts = line.split()
        if len(parts) < 2 or not valid_ip_literal(parts[0]):
            continue
        address = ipaddress.ip_address(parts[0])
        for name in parts[1:]:
            hosts.setdefault(name.rstrip(".").lower(), []).append(address)
    return hosts


def hostnames_from_text(text):
    names = []
    seen = set()
    for host in parse_hosts_text(text):
        if host not in seen:
            seen.add(host)
            names.append(host)
    return names


def build_merged(extra, enabled):
    try:
        base = read_text(BASE_HOSTS)
    except OSError:
        base = "127.0.0.1 localhost\n255.255.255.255 broadcasthost\n::1 localhost\n"
    if base and not base.endswith("\n"):
        base += "\n"
    if enabled:
        return base + "\n# EtcHosts17 supplemental entries begin\n" + extra + "# EtcHosts17 supplemental entries end\n"
    return base


def sync_caches():
    """Write only runtime caches. Never touches the preferences plist."""
    ensure_storage()
    text = read_hosts_text()
    try:
        text = validated_hosts_text(text)
    except ValueError as exc:
        log("invalid hosts text, using default: %s" % exc)
        text = DEFAULT_EXTRA
    enabled = read_settings().get(PREFS_ENABLED_KEY, True)
    try:
        write_text(DAEMON_HOSTS, text)
        merged = build_merged(text, enabled)
        write_text(ROOTFS_MERGED, merged)
        write_text(JBROOT_MERGED, merged)
    except OSError as exc:
        log("cache write failed: %s" % exc)
    return text


# ---------------------------------------------------------------------------
# DNS wire helpers
# ---------------------------------------------------------------------------

def parse_question(packet):
    if len(packet) < 12:
        return None
    offset = 12
    labels = []
    while offset < len(packet):
        length = packet[offset]
        offset += 1
        if length == 0:
            break
        if length & 0xC0 or offset + length > len(packet):
            return None
        labels.append(packet[offset:offset + length].decode("ascii", "ignore"))
        offset += length
    if offset + 4 > len(packet):
        return None
    qtype, qclass = struct.unpack("!HH", packet[offset:offset + 4])
    return ".".join(labels).lower(), qtype, qclass, offset + 4


def empty_response(packet, question_end):
    return packet[:2] + b"\x81\x80\x00\x01\x00\x00\x00\x00\x00\x00" + packet[12:question_end]


def answer_response(packet, question_end, address):
    rtype = 1 if address.version == 4 else 28
    answer = (
        b"\xc0\x0c"
        + struct.pack("!HHI", rtype, 1, 60)
        + struct.pack("!H", len(address.packed))
        + address.packed
    )
    return packet[:2] + b"\x81\x80\x00\x01\x00\x01\x00\x00\x00\x00" + packet[12:question_end] + answer


def forward(packet, upstreams, timeout=3):
    for upstream in upstreams:
        family = socket.AF_INET6 if ":" in upstream else socket.AF_INET
        sock = socket.socket(family, socket.SOCK_DGRAM)
        sock.settimeout(timeout)
        try:
            sock.sendto(packet, (upstream, 53))
            response, _ = sock.recvfrom(4096)
            return response
        except OSError:
            pass
        finally:
            sock.close()
    return None


def handle_query(packet):
    """Resolve one DNS query packet. Returns the response bytes (or None)."""
    parsed = parse_question(packet)
    if not parsed:
        return None
    name, qtype, _qclass, qend = parsed

    # Suppress DDR so mDNSResponder does not auto-upgrade to an encrypted
    # designated resolver that would bypass this daemon.
    if name.endswith("resolver.arpa"):
        return empty_response(packet, qend)

    addresses = STATE["hosts"].get(name)
    if addresses:
        match = None
        for address in addresses:
            if (qtype == 1 and address.version == 4) or (qtype == 28 and address.version == 6):
                match = address
                break
        if match:
            return answer_response(packet, qend, match)
        # A/AAAA of the other family, or HTTPS/SVCB: answer NODATA so no real
        # address (or ipv4hint) leaks for an overridden host.
        return empty_response(packet, qend)

    # Not overridden. In scoped mode these barely reach us; in global mode every
    # query does. FallbackSystemDNS ON -> forward to public upstreams; OFF ->
    # strict allowlist (answer NODATA so only listed hosts ever resolve).
    if not STATE["fallback"]:
        return empty_response(packet, qend)
    response = forward(packet, STATE.get("upstreams") or UPSTREAMS)
    return response if response else empty_response(packet, qend)


# ---------------------------------------------------------------------------
# DNS-over-TLS listener (the profile points scoped domains here)
# ---------------------------------------------------------------------------

def recv_exact(sock, count):
    chunks = []
    while count > 0:
        chunk = sock.recv(count)
        if not chunk:
            return None
        chunks.append(chunk)
        count -= len(chunk)
    return b"".join(chunks)


def dot_connection(tls):
    try:
        while True:
            header = recv_exact(tls, 2)
            if not header:
                break
            (length,) = struct.unpack("!H", header)
            message = recv_exact(tls, length)
            if not message:
                break
            response = handle_query(message)
            if response is None:
                continue
            tls.sendall(struct.pack("!H", len(response)) + response)
    except (OSError, ssl.SSLError):
        pass
    finally:
        try:
            tls.close()
        except OSError:
            pass


def dot_server():
    if not (os.path.exists(SERVER_CERT) and os.path.exists(SERVER_KEY)):
        log("DoT listener disabled: no certificate at %s" % SERVER_CERT)
        return
    try:
        context = ssl.SSLContext(ssl.PROTOCOL_TLS_SERVER)
        context.load_cert_chain(SERVER_CERT, SERVER_KEY)
    except Exception as exc:
        log("DoT listener disabled: cannot load cert: %s" % exc)
        return
    listener = socket.socket(socket.AF_INET, socket.SOCK_STREAM)
    listener.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    try:
        bind_with_retry(listener, ("0.0.0.0", DOT_PORT))
    except OSError as exc:
        log("DoT listener bind failed: %s" % exc)
        return
    listener.listen(32)
    log("EtcHosts17 DoT listener on 0.0.0.0:%d" % DOT_PORT)
    while True:
        try:
            client, _addr = listener.accept()
        except OSError:
            continue
        try:
            tls = context.wrap_socket(client, server_side=True)
        except (OSError, ssl.SSLError):
            try:
                client.close()
            except OSError:
                pass
            continue
        threading.Thread(target=dot_connection, args=(tls,), daemon=True).start()


# ---------------------------------------------------------------------------
# .mobileconfig generation + localhost delivery
# ---------------------------------------------------------------------------

def local_interface_ip():
    try:
        probe = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        probe.connect(("1.1.1.1", 53))
        ip = probe.getsockname()[0]
        probe.close()
        return ip
    except OSError:
        return None


def _det_uuid(tag):
    return str(uuid.uuid5(uuid.NAMESPACE_DNS, "etchosts17." + tag)).upper()


def build_profile_data():
    """Generate the scoped DoT .mobileconfig from the current override hosts."""
    match = [h for h in STATE["hosts"].keys() if h != "localhost"]
    match.sort()
    # Bind only to loopback: the interface IP is dynamic (changes per Wi-Fi/
    # cellular network) so it must never be baked into the profile.
    servers = ["127.0.0.1"]

    try:
        with open(CA_DER, "rb") as handle:
            ca_der = handle.read()
    except OSError:
        ca_der = b""

    cert_payload = {
        "PayloadType": "com.apple.security.root",
        "PayloadVersion": 1,
        "PayloadIdentifier": PROFILE_ID + ".ca",
        "PayloadUUID": _det_uuid("ca"),
        "PayloadDisplayName": "EtcHosts17 Local CA",
        "PayloadDescription": "Trusts the local EtcHosts17 DNS-over-TLS resolver.",
        "PayloadCertificateFileName": "EtcHosts17CA.cer",
        "PayloadContent": ca_der,
    }
    dns_settings = {
        "DNSProtocol": "TLS",
        "ServerName": PROFILE_SERVER_NAME,
        "ServerAddresses": servers,
    }
    # Scoped mode: only the listed hosts are routed here (SupplementalMatchDomains),
    # so editor changes to the *set of hostnames* need a profile reinstall. Global
    # mode: no match list -> this becomes the primary resolver for every query, so
    # any editor change is picked up live with no reinstall.
    if match and not STATE.get("global"):
        dns_settings["SupplementalMatchDomains"] = match
    dns_payload = {
        "PayloadType": "com.apple.dnsSettings.managed",
        "PayloadVersion": 1,
        "PayloadIdentifier": PROFILE_ID + ".dnssettings",
        "PayloadUUID": _det_uuid("dns"),
        "PayloadDisplayName": "EtcHosts17 DNS",
        "PayloadDescription": "Routes the overridden hosts to the local resolver.",
        "DNSSettings": dns_settings,
    }
    top = {
        "PayloadType": "Configuration",
        "PayloadVersion": 1,
        "PayloadIdentifier": PROFILE_ID,
        "PayloadUUID": _det_uuid("root"),
        "PayloadDisplayName": "/etc/hosts (iOS 17.0)",
        "PayloadDescription": (
            ("Routes ALL DNS to the local EtcHosts17 resolver over encrypted DNS "
             "(DoT); %d host(s) overridden, the rest forwarded upstream." % len(match))
            if STATE.get("global") else
            ("Routes %d listed host(s) to the local EtcHosts17 resolver over "
             "encrypted DNS (DoT), overriding DoH/VPN for those names." % len(match))
        ),
        "PayloadOrganization": "EtcHosts17",
        "PayloadRemovalDisallowed": False,
        "PayloadContent": [cert_payload, dns_payload],
    }
    return plistlib.dumps(top, fmt=plistlib.FMT_XML)


class _ProfileHandler(BaseHTTPRequestHandler):
    def do_GET(self):  # noqa: N802 (http.server API)
        try:
            data = build_profile_data()
        except Exception as exc:
            self.send_error(500, "profile error: %s" % exc)
            return
        self.send_response(200)
        self.send_header("Content-Type", "application/x-apple-aspen-config")
        self.send_header("Content-Disposition",
                         'attachment; filename="%s"' % PROFILE_FILENAME)
        self.send_header("Content-Length", str(len(data)))
        self.end_headers()
        self.wfile.write(data)

    def log_message(self, *args):
        return


def profile_http_server():
    try:
        server = ThreadingHTTPServer(("127.0.0.1", PROFILE_HTTP_PORT), _ProfileHandler)
    except OSError as exc:
        log("profile HTTP server bind failed: %s" % exc)
        return
    log("EtcHosts17 profile server on 127.0.0.1:%d" % PROFILE_HTTP_PORT)
    server.serve_forever()


# ---------------------------------------------------------------------------
# Daemon
# ---------------------------------------------------------------------------

STATE = {"hosts": {}, "enabled": True, "fallback": True, "global": False, "upstreams": list(UPSTREAMS)}
WAKE = threading.Event()


def reload_state():
    settings = read_settings()
    STATE["enabled"] = settings.get(PREFS_ENABLED_KEY, True)
    STATE["fallback"] = settings.get(PREFS_FALLBACK_KEY, True)
    STATE["global"] = settings.get(PREFS_GLOBAL_KEY, False)
    STATE["upstreams"] = read_upstreams()
    text = sync_caches()
    STATE["hosts"] = parse_hosts_text(text) if STATE["enabled"] else {}
    log("loaded %d override host(s), enabled=%s global=%s fallback=%s"
        % (len(STATE["hosts"]), STATE["enabled"], STATE["global"], STATE["fallback"]))


def watcher():
    last = None
    while True:
        try:
            paths = (DAEMON_HOSTS, ROOTFS_PREFS, JBROOT_PREFS, UPSTREAMS_FILE)
            stamp = tuple((p, os.stat(p).st_mtime) for p in paths if os.path.exists(p))
            if stamp != last:
                reload_state()
                last = stamp
        except Exception as exc:
            log("watcher error: %s" % exc)
        WAKE.wait(10)
        WAKE.clear()


def bind_with_retry(sock, addr, attempts=40, delay=0.5):
    for attempt in range(attempts):
        try:
            sock.bind(addr)
            return
        except OSError as exc:
            if attempt == attempts - 1:
                raise
            if attempt == 0:
                log("waiting for %s:%s: %s" % (addr[0], addr[1], exc))
            time.sleep(delay)


def daemon():
    ensure_storage()
    reload_state()

    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    bind_with_retry(sock, ("0.0.0.0", 53))
    sockets = [sock]
    sock6 = None
    try:
        sock6 = socket.socket(socket.AF_INET6, socket.SOCK_DGRAM)
        sock6.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock6.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 1)
        sock6.bind(("::", 53))
        sockets.append(sock6)
    except OSError as exc:
        log("IPv6 listener unavailable: %s" % exc)

    control = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    control.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    bind_with_retry(control, ("127.0.0.1", CONTROL_PORT))

    log("EtcHosts17 DNS daemon on 0.0.0.0:53" + (" and [::]:53" if sock6 else ""))
    threading.Thread(target=watcher, daemon=True).start()
    threading.Thread(target=dot_server, daemon=True).start()
    threading.Thread(target=profile_http_server, daemon=True).start()

    while True:
        try:
            ready, _, _ = select.select(sockets + [control], [], [], 30)
            if not ready:
                continue
            if control in ready:
                payload, _client = control.recvfrom(65535)
                if payload.startswith(CONTROL_APPLY_MAGIC):
                    log("control apply")
                    WAKE.set()
                elif payload.startswith(CONTROL_MAGIC):
                    text = payload[len(CONTROL_MAGIC):].decode("utf-8", "ignore")
                    try:
                        text = validated_hosts_text(text)
                    except ValueError as exc:
                        log("rejected control update: %s" % exc)
                        continue
                    # Runtime cache only -- never the preferences plist.
                    write_text(DAEMON_HOSTS, text)
                    STATE["hosts"] = parse_hosts_text(text) if STATE["enabled"] else {}
                    log("control update: %d host(s)" % len(STATE["hosts"]))
                continue

            query_sock = sock6 if (sock6 and sock6 in ready) else sock
            packet, client = query_sock.recvfrom(4096)
            response = handle_query(packet)
            if response is not None:
                query_sock.sendto(response, client)
        except Exception as exc:
            log("request error: %s" % exc)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["daemon", "apply", "sync", "profile"], nargs="?", default="apply")
    args = parser.parse_args()
    if args.mode == "daemon":
        daemon()
    elif args.mode == "profile":
        # Emit the generated profile to stdout (diagnostics / offline install).
        reload_state()
        sys.stdout.buffer.write(build_profile_data())
    else:
        sync_caches()
        log("%s complete" % args.mode)


if __name__ == "__main__":
    main()
