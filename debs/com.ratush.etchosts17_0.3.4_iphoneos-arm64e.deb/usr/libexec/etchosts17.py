#!/usr/bin/env python3
import argparse
import fcntl
import ipaddress
import os
import plistlib
import shutil
import select
import socket
import struct
import subprocess
import sys
import time


ROOTFS_DIR = "/rootfs/private/var/mobile/Library/EtcHosts17"
JBROOT_DIR = "/var/mobile/Library/EtcHosts17"
ROOTFS_EXTRA = ROOTFS_DIR + "/hosts.extra"
JBROOT_EXTRA = JBROOT_DIR + "/hosts.extra"
ROOTFS_MERGED = ROOTFS_DIR + "/hosts.merged"
JBROOT_MERGED = JBROOT_DIR + "/hosts.merged"
ROOTFS_PREFS = "/rootfs/private/var/mobile/Library/Preferences/com.ratush.etchosts17.plist"
JBROOT_PREFS = "/var/mobile/Library/Preferences/com.ratush.etchosts17.plist"
PREFS_HOSTS_KEY = "HostsText"
BASE_HOSTS = "/etc/hosts"
PREFERENCES = "/rootfs/private/var/preferences/SystemConfiguration/preferences.plist"
PREFERENCES_BACKUP = "/rootfs/private/var/preferences/SystemConfiguration/preferences.plist.bak.etchosts17"
DAEMON_HOSTS = "/usr/libexec/etchosts17.hosts"
CONTROL_MAGIC = b"ETCHOSTS17\n"
CONTROL_PORT = 53535
DEFAULT_EXTRA = "# EtcHosts17 supplemental entries\n# Example:\n# 0.0.0.0 example.com\n"
ENFORCE_INTERVAL = 15
DNS_ALIASES = ["1.1.1.1", "1.0.0.1", "8.8.8.8", "8.8.4.4"]


def log(message):
    sys.stderr.write(time.strftime("%Y-%m-%d %H:%M:%S ") + message + "\n")
    sys.stderr.flush()


def ensure_storage():
    for path in (ROOTFS_DIR, JBROOT_DIR):
        os.makedirs(path, exist_ok=True)
        try:
            os.chmod(path, 0o755)
        except OSError:
            pass


def read_text(path):
    with open(path, "r", encoding="utf-8", errors="ignore") as handle:
        return handle.read()


def write_text(path, text, mode=0o644):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as handle:
        handle.write(text)
    os.chmod(tmp, mode)
    os.replace(tmp, path)


def newest_existing(paths):
    existing = [p for p in paths if os.path.exists(p)]
    if not existing:
        return None
    return max(existing, key=lambda p: os.stat(p).st_mtime)


def read_hosts_from_plist(path):
    with open(path, "rb") as handle:
        prefs = plistlib.load(handle)
    value = prefs.get(PREFS_HOSTS_KEY)
    if isinstance(value, str):
        return value
    return ""


def write_hosts_plist(path, text):
    parent = os.path.dirname(path)
    os.makedirs(parent, exist_ok=True)
    prefs = {}
    try:
        with open(path, "rb") as handle:
            prefs = plistlib.load(handle)
    except Exception:
        prefs = {}
    prefs[PREFS_HOSTS_KEY] = text
    prefs["LastSaved"] = time.time()
    tmp = path + ".tmp"
    with open(tmp, "wb") as handle:
        plistlib.dump(prefs, handle, fmt=plistlib.FMT_BINARY)
    os.chmod(tmp, 0o644)
    os.replace(tmp, path)


def best_hosts_source():
    candidates = []
    for path, kind in (
        (ROOTFS_PREFS, "plist"),
        (JBROOT_PREFS, "plist"),
        (DAEMON_HOSTS, "text"),
        (ROOTFS_EXTRA, "text"),
        (JBROOT_EXTRA, "text"),
    ):
        if os.path.exists(path):
            candidates.append((os.stat(path).st_mtime, path, kind))
    if not candidates:
        return None, None
    _mtime, path, kind = max(candidates)
    return path, kind


def sync_hosts():
    ensure_storage()
    source, source_kind = best_hosts_source()
    if source_kind == "plist":
        extra = read_hosts_from_plist(source)
    elif source_kind == "text":
        extra = read_text(source)
    else:
        extra = DEFAULT_EXTRA
    if extra and not extra.endswith("\n"):
        extra += "\n"
    write_hosts_plist(ROOTFS_PREFS, extra)
    write_hosts_plist(JBROOT_PREFS, extra)
    write_text(ROOTFS_EXTRA, extra)
    write_text(JBROOT_EXTRA, extra)
    write_text(DAEMON_HOSTS, extra)

    try:
        base = read_text(BASE_HOSTS)
    except OSError:
        base = "127.0.0.1 localhost\n255.255.255.255 broadcasthost\n::1 localhost\n"
    if base and not base.endswith("\n"):
        base += "\n"
    merged = base + "\n# EtcHosts17 supplemental entries begin\n" + extra + "# EtcHosts17 supplemental entries end\n"
    write_text(ROOTFS_MERGED, merged)
    write_text(JBROOT_MERGED, merged)
    log("synced supplemental hosts from %s" % (source or "default"))


def parse_hosts_text(text):
    hosts = {}
    for raw_line in text.splitlines():
        line = raw_line.split("#", 1)[0].strip()
        if not line:
            continue
        parts = line.split()
        if len(parts) < 2:
            continue
        try:
            address = ipaddress.ip_address(parts[0])
        except ValueError:
            continue
        for name in parts[1:]:
            hosts.setdefault(name.rstrip(".").lower(), []).append(address)
    return hosts


def load_hosts():
    for path, kind in ((DAEMON_HOSTS, "text"), (ROOTFS_PREFS, "plist"), (JBROOT_PREFS, "plist"), (ROOTFS_EXTRA, "text"), (JBROOT_EXTRA, "text")):
        try:
            if kind == "plist":
                return parse_hosts_text(read_hosts_from_plist(path))
            return parse_hosts_text(read_text(path))
        except OSError as exc:
            log("cannot read %s: %s" % (path, exc))
    try:
        return parse_hosts_text(read_text(DAEMON_HOSTS))
    except OSError as exc:
        log("cannot read %s: %s" % (DAEMON_HOSTS, exc))
    return {}


def local_ipv4():
    try:
        return interface_ipv4("en0")
    except Exception as exc:
        log("could not read en0 IPv4: %s" % exc)
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("1.1.1.1", 53))
        return sock.getsockname()[0]
    finally:
        sock.close()


def interface_ipv4(name):
    request = struct.pack("256s", name[:15].encode("utf-8"))
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        response = fcntl.ioctl(sock.fileno(), 0xC0206921, request)
        return socket.inet_ntoa(response[20:24])
    finally:
        sock.close()


def is_dns_service_candidate(service):
    interface = service.get("Interface", {})
    if interface.get("DeviceName") == "en0" and interface.get("Hardware") == "AirPort":
        return True
    if interface.get("Type") == "VPN":
        return True
    return False


def configure_dns(server_ip=None):
    server_ip = server_ip or local_ipv4()
    with open(PREFERENCES, "rb") as handle:
        prefs = plistlib.load(handle)
    if not os.path.exists(PREFERENCES_BACKUP):
        shutil.copy2(PREFERENCES, PREFERENCES_BACKUP)

    current = str(prefs.get("CurrentSet", "")).split("/")[-1]
    service_order = (
        prefs.get("Sets", {})
        .get(current, {})
        .get("Network", {})
        .get("Global", {})
        .get("IPv4", {})
        .get("ServiceOrder", [])
    )
    services = prefs.get("NetworkServices", {})
    selected = []
    for service_id in service_order + list(services.keys()):
        service = services.get(service_id, {})
        if service_id not in selected and is_dns_service_candidate(service):
            selected.append(service_id)
    if not selected:
        raise RuntimeError("could not find Wi-Fi or VPN DNS services")

    changed = False
    for service_id in selected:
        desired = {"ServerAddresses": [server_ip]}
        if services[service_id].get("DNS") != desired:
            services[service_id]["DNS"] = desired
            changed = True
    if not changed:
        log("DNS enforcement already points %d service(s) to %s" % (len(selected), server_ip))
        return server_ip, False
    tmp = PREFERENCES + ".etchosts17tmp"
    with open(tmp, "wb") as handle:
        plistlib.dump(prefs, handle, fmt=plistlib.FMT_BINARY)
    os.chown(tmp, 0, 0)
    os.chmod(tmp, 0o644)
    os.replace(tmp, PREFERENCES)
    log("configured %d Wi-Fi/VPN DNS service(s) -> %s" % (len(selected), server_ip))
    return server_ip, True


def reload_resolver():
    commands = [
        ["/usr/bin/launchctl", "kickstart", "-k", "user/501/com.apple.configd"],
        ["/usr/bin/killall", "-HUP", "mDNSResponder"],
    ]
    for command in commands:
        try:
            subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=8)
        except Exception as exc:
            log("reload command failed %s: %s" % (" ".join(command), exc))


def install_loopback_aliases():
    for address in DNS_ALIASES:
        try:
            subprocess.run(
                ["/usr/sbin/ifconfig", "lo0", "alias", address, "255.255.255.255"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=5,
            )
            log("ensured lo0 DNS alias %s" % address)
        except Exception as exc:
            log("could not add lo0 alias %s: %s" % (address, exc))


def remove_loopback_aliases():
    for address in DNS_ALIASES:
        try:
            subprocess.run(
                ["/usr/sbin/ifconfig", "lo0", "-alias", address],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=5,
            )
        except Exception:
            pass


def parse_question(packet):
    if len(packet) < 12:
        return None
    offset = 12
    labels = []
    while offset < len(packet):
        length = packet[offset]
        offset += 1
        if length == 0:
            break
        if length & 0xC0 or offset + length > len(packet):
            return None
        labels.append(packet[offset:offset + length].decode("ascii", "ignore"))
        offset += length
    if offset + 4 > len(packet):
        return None
    qtype, qclass = struct.unpack("!HH", packet[offset:offset + 4])
    return ".".join(labels).lower(), qtype, qclass, offset + 4


def empty_response(packet, question_end):
    return packet[:2] + b"\x81\x80\x00\x01\x00\x00\x00\x00\x00\x00" + packet[12:question_end]


def answer_response(packet, question_end, address):
    rtype = 1 if address.version == 4 else 28
    answer = (
        b"\xc0\x0c"
        + struct.pack("!HHI", rtype, 1, 60)
        + struct.pack("!H", len(address.packed))
        + address.packed
    )
    return packet[:2] + b"\x81\x80\x00\x01\x00\x01\x00\x00\x00\x00" + packet[12:question_end] + answer


def forward(packet, upstreams):
    for upstream in upstreams:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(2)
        try:
            sock.sendto(packet, (upstream, 53))
            response, _ = sock.recvfrom(4096)
            return response
        except OSError:
            pass
        finally:
            sock.close()
    return None


def daemon():
    ensure_storage()
    try:
        sync_hosts()
    except Exception as exc:
        log("initial host sync failed: %s" % exc)
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(("0.0.0.0", 53))
    control = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    control.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    control.bind(("127.0.0.1", CONTROL_PORT))
    log("EtcHosts17 DNS daemon listening on 0.0.0.0:53")
    log("EtcHosts17 control listening on 127.0.0.1:%d" % CONTROL_PORT)
    last_mtime = None
    hosts = {}
    last_enforce = 0
    while True:
        try:
            now = time.time()
            if now - last_enforce >= ENFORCE_INTERVAL:
                try:
                    _ip, changed = configure_dns()
                    if changed:
                        reload_resolver()
                except Exception as exc:
                    log("DNS enforcement failed: %s" % exc)
                last_enforce = now
            mtimes = tuple((p, os.stat(p).st_mtime) for p in (DAEMON_HOSTS, ROOTFS_EXTRA, JBROOT_EXTRA) if os.path.exists(p))
            if mtimes != last_mtime:
                hosts = load_hosts()
                last_mtime = mtimes
                log("loaded %d override host(s)" % len(hosts))
            ready, _, _ = select.select([sock, control], [], [], 30)
            if not ready:
                continue
            if control in ready:
                payload, _client = control.recvfrom(65535)
                if payload.startswith(CONTROL_MAGIC):
                    text = payload[len(CONTROL_MAGIC):].decode("utf-8", "ignore")
                    if text and not text.endswith("\n"):
                        text += "\n"
                    write_hosts_plist(ROOTFS_PREFS, text)
                    write_hosts_plist(JBROOT_PREFS, text)
                    write_text(DAEMON_HOSTS, text)
                    hosts = parse_hosts_text(text)
                    last_mtime = None
                    log("control update loaded %d override host(s)" % len(hosts))
                continue
            packet, client = sock.recvfrom(4096)
            parsed = parse_question(packet)
            if not parsed:
                continue
            name, qtype, _qclass, question_end = parsed
            addresses = hosts.get(name)
            if addresses:
                match = None
                for address in addresses:
                    if (qtype == 1 and address.version == 4) or (qtype == 28 and address.version == 6):
                        match = address
                        break
                if match:
                    sock.sendto(answer_response(packet, question_end, match), client)
                    log("override %s -> %s" % (name, match))
                else:
                    sock.sendto(empty_response(packet, question_end), client)
                    log("suppress %s qtype %d" % (name, qtype))
                continue
            response = forward(packet, ["9.9.9.9", "94.140.14.14", "208.67.222.222"])
            if response:
                sock.sendto(response, client)
        except Exception as exc:
            log("daemon request error: %s" % exc)


def apply():
    sync_hosts()
    install_loopback_aliases()
    ip, changed = configure_dns()
    if changed:
        reload_resolver()
    log("apply complete with DNS %s" % ip)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["apply", "daemon", "sync", "unalias"], nargs="?", default="apply")
    args = parser.parse_args()
    if args.mode == "daemon":
        daemon()
    elif args.mode == "sync":
        sync_hosts()
    elif args.mode == "unalias":
        remove_loopback_aliases()
    else:
        apply()


if __name__ == "__main__":
    main()
