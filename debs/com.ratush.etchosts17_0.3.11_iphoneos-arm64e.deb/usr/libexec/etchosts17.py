#!/usr/bin/env python3
import argparse
import fcntl
import ipaddress
import os
import plistlib
import re
import shutil
import select
import socket
import struct
import subprocess
import sys
import time


ROOTFS_DIR = "/rootfs/private/var/mobile/Library/EtcHosts17"
JBROOT_DIR = "/var/mobile/Library/EtcHosts17"
ROOTFS_EXTRA = ROOTFS_DIR + "/hosts.extra"
JBROOT_EXTRA = JBROOT_DIR + "/hosts.extra"
ROOTFS_MERGED = ROOTFS_DIR + "/hosts.merged"
JBROOT_MERGED = JBROOT_DIR + "/hosts.merged"
ROOTFS_PREFS = "/rootfs/private/var/mobile/Library/Preferences/com.ratush.etchosts17.plist"
JBROOT_PREFS = "/var/mobile/Library/Preferences/com.ratush.etchosts17.plist"
PREFS_HOSTS_KEY = "HostsText"
PREFS_ENABLED_KEY = "Enabled"
PREFS_OVERRIDE_VPN_KEY = "OverrideVPNDNS"
PREFS_PRIORITIZE_PROFILES_KEY = "PrioritizeDNSProfiles"
PREFS_FALLBACK_KEY = "FallbackSystemDNS"
PREFS_PRESETS_KEY = "Presets"
PREFS_SELECTED_PRESET_KEY = "SelectedPreset"
BASE_HOSTS = "/etc/hosts"
PREFERENCES = "/rootfs/private/var/preferences/SystemConfiguration/preferences.plist"
PREFERENCES_BACKUP = "/rootfs/private/var/preferences/SystemConfiguration/preferences.plist.bak.etchosts17"
DAEMON_HOSTS = "/usr/libexec/etchosts17.hosts"
CONTROL_MAGIC = b"ETCHOSTS17\n"
CONTROL_PORT = 53535
DEFAULT_EXTRA = "# EtcHosts17 supplemental entries\n# Example:\n# 0.0.0.0 example.com\n"
ENFORCE_INTERVAL = 15
DNS_ALIASES = ["1.1.1.1", "1.0.0.1", "8.8.8.8", "8.8.4.4"]
DNS_ALIASES_V6 = [
    "2606:4700:4700::1111",
    "2606:4700:4700::1001",
    "2001:4860:4860::8888",
    "2001:4860:4860::8844",
    "2620:fe::fe",
    "2620:fe::9",
    "2a10:50c0::ad1:ff",
    "2a10:50c0::ad2:ff",
]
UPSTREAMS = ["9.9.9.9", "94.140.14.14", "208.67.222.222"]
IPV4_RE = re.compile(r"^[0-9]{1,3}(\.[0-9]{1,3}){3}$")
DOMAIN_RE = re.compile(r"^[A-Za-z0-9]+(\.[A-Za-z0-9]+)+$")


def log(message):
    sys.stderr.write(time.strftime("%Y-%m-%d %H:%M:%S ") + message + "\n")
    sys.stderr.flush()


def ensure_storage():
    for path in (ROOTFS_DIR, JBROOT_DIR):
        os.makedirs(path, exist_ok=True)
        try:
            os.chmod(path, 0o755)
        except OSError:
            pass


def read_text(path):
    with open(path, "r", encoding="utf-8", errors="ignore") as handle:
        return handle.read()


def write_text(path, text, mode=0o644):
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as handle:
        handle.write(text)
    os.chmod(tmp, mode)
    os.replace(tmp, path)


def newest_existing(paths):
    existing = [p for p in paths if os.path.exists(p)]
    if not existing:
        return None
    return max(existing, key=lambda p: os.stat(p).st_mtime)


def default_settings():
    return {
        PREFS_ENABLED_KEY: True,
        PREFS_OVERRIDE_VPN_KEY: True,
        PREFS_PRIORITIZE_PROFILES_KEY: False,
        PREFS_FALLBACK_KEY: True,
        PREFS_SELECTED_PRESET_KEY: "Default",
    }


def read_plist_dict(path):
    with open(path, "rb") as handle:
        value = plistlib.load(handle)
    return value if isinstance(value, dict) else {}


def read_hosts_from_plist(path):
    prefs = read_plist_dict(path)
    value = prefs.get(PREFS_HOSTS_KEY)
    if isinstance(value, str):
        return value
    return ""


def read_settings():
    settings = default_settings()
    for path in (ROOTFS_PREFS, JBROOT_PREFS):
        try:
            prefs = read_plist_dict(path)
        except Exception:
            continue
        for key in (PREFS_ENABLED_KEY, PREFS_OVERRIDE_VPN_KEY, PREFS_PRIORITIZE_PROFILES_KEY, PREFS_FALLBACK_KEY):
            if isinstance(prefs.get(key), bool):
                settings[key] = prefs[key]
        if isinstance(prefs.get(PREFS_SELECTED_PRESET_KEY), str) and prefs[PREFS_SELECTED_PRESET_KEY]:
            settings[PREFS_SELECTED_PRESET_KEY] = prefs[PREFS_SELECTED_PRESET_KEY]
        break
    return settings


def write_hosts_plist(path, text):
    parent = os.path.dirname(path)
    os.makedirs(parent, exist_ok=True)
    prefs = {}
    try:
        with open(path, "rb") as handle:
            prefs = plistlib.load(handle)
    except Exception:
        prefs = {}
    defaults = default_settings()
    for key, value in defaults.items():
        prefs.setdefault(key, value)
    presets = prefs.get(PREFS_PRESETS_KEY)
    if not isinstance(presets, dict):
        presets = {"Default": text}
    presets.setdefault(prefs.get(PREFS_SELECTED_PRESET_KEY, "Default"), text)
    prefs[PREFS_PRESETS_KEY] = presets
    prefs[PREFS_HOSTS_KEY] = text
    prefs["LastSaved"] = time.time()
    tmp = path + ".tmp"
    with open(tmp, "wb") as handle:
        plistlib.dump(prefs, handle, fmt=plistlib.FMT_BINARY)
    try:
        os.chown(tmp, 501, 501)
    except OSError:
        pass
    os.chmod(tmp, 0o644)
    os.replace(tmp, path)


def best_hosts_source():
    candidates = []
    for path, kind in (
        (ROOTFS_PREFS, "plist"),
        (JBROOT_PREFS, "plist"),
        (DAEMON_HOSTS, "text"),
        (ROOTFS_EXTRA, "text"),
        (JBROOT_EXTRA, "text"),
    ):
        if os.path.exists(path):
            candidates.append((os.stat(path).st_mtime, path, kind))
    if not candidates:
        return None, None
    _mtime, path, kind = max(candidates)
    return path, kind


def normalize_hosts_text(text):
    value = (text or "").replace("\r\n", "\n").replace("\r", "\n")
    if value and not value.endswith("\n"):
        value += "\n"
    return value


def validation_errors(text):
    errors = []
    for index, raw_line in enumerate(normalize_hosts_text(text).splitlines(), start=1):
        line = raw_line.strip()
        if not line or line.startswith("#"):
            continue
        parts = line.split()
        if len(parts) != 2:
            errors.append("line %d: use exactly 'IPv4 domain'" % index)
            continue
        ip, domain = parts
        if not IPV4_RE.match(ip):
            errors.append("line %d: invalid IPv4 address %r" % (index, ip))
            continue
        octets = [int(part) for part in ip.split(".")]
        if any(part < 0 or part > 255 for part in octets):
            errors.append("line %d: IPv4 octet must be 0-255" % index)
            continue
        if not DOMAIN_RE.match(domain):
            errors.append("line %d: invalid domain %r" % (index, domain))
    return errors


def validated_hosts_text(text):
    value = normalize_hosts_text(text)
    errors = validation_errors(value)
    if errors:
        raise ValueError("; ".join(errors))
    return value


def sync_hosts():
    ensure_storage()
    source, source_kind = best_hosts_source()
    if source_kind == "plist":
        extra = read_hosts_from_plist(source)
    elif source_kind == "text":
        extra = read_text(source)
    else:
        extra = DEFAULT_EXTRA
    try:
        extra = validated_hosts_text(extra)
    except ValueError as exc:
        log("invalid supplemental hosts in %s: %s" % (source or "default", exc))
        extra = DEFAULT_EXTRA
    write_hosts_plist(ROOTFS_PREFS, extra)
    write_hosts_plist(JBROOT_PREFS, extra)
    write_text(ROOTFS_EXTRA, extra)
    write_text(JBROOT_EXTRA, extra)
    write_text(DAEMON_HOSTS, extra)

    try:
        base = read_text(BASE_HOSTS)
    except OSError:
        base = "127.0.0.1 localhost\n255.255.255.255 broadcasthost\n::1 localhost\n"
    if base and not base.endswith("\n"):
        base += "\n"
    merged = base + "\n# EtcHosts17 supplemental entries begin\n" + extra + "# EtcHosts17 supplemental entries end\n"
    write_text(ROOTFS_MERGED, merged)
    write_text(JBROOT_MERGED, merged)
    log("synced supplemental hosts from %s" % (source or "default"))


def parse_hosts_text(text):
    text = validated_hosts_text(text)
    hosts = {}
    for raw_line in text.splitlines():
        line = raw_line.strip()
        if not line:
            continue
        parts = line.split()
        if not parts or parts[0].startswith("#"):
            continue
        address = ipaddress.ip_address(parts[0])
        hosts.setdefault(parts[1].rstrip(".").lower(), []).append(address)
    return hosts


def load_hosts():
    for path, kind in ((DAEMON_HOSTS, "text"), (ROOTFS_PREFS, "plist"), (JBROOT_PREFS, "plist"), (ROOTFS_EXTRA, "text"), (JBROOT_EXTRA, "text")):
        try:
            if kind == "plist":
                return parse_hosts_text(read_hosts_from_plist(path))
            return parse_hosts_text(read_text(path))
        except Exception as exc:
            log("cannot load %s: %s" % (path, exc))
    try:
        return parse_hosts_text(read_text(DAEMON_HOSTS))
    except OSError as exc:
        log("cannot read %s: %s" % (DAEMON_HOSTS, exc))
    return {}


def local_ipv4():
    try:
        return interface_ipv4("en0")
    except Exception as exc:
        log("could not read en0 IPv4: %s" % exc)
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        sock.connect(("1.1.1.1", 53))
        return sock.getsockname()[0]
    finally:
        sock.close()


def interface_ipv4(name):
    request = struct.pack("256s", name[:15].encode("utf-8"))
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    try:
        response = fcntl.ioctl(sock.fileno(), 0xC0206921, request)
        return socket.inet_ntoa(response[20:24])
    finally:
        sock.close()


def is_vpn_service(service):
    return service.get("Interface", {}).get("Type") == "VPN"


def is_wifi_service(service):
    interface = service.get("Interface", {})
    if interface.get("DeviceName") == "en0" and interface.get("Hardware") == "AirPort":
        return True
    return False


def is_dns_service_candidate(service, settings):
    if is_wifi_service(service):
        return True
    if settings.get(PREFS_OVERRIDE_VPN_KEY, True) and is_vpn_service(service):
        return True
    return False


def configure_dns(server_ip=None, settings=None):
    settings = settings or read_settings()
    server_ip = server_ip or local_ipv4()
    with open(PREFERENCES, "rb") as handle:
        prefs = plistlib.load(handle)
    if not os.path.exists(PREFERENCES_BACKUP):
        shutil.copy2(PREFERENCES, PREFERENCES_BACKUP)

    current = str(prefs.get("CurrentSet", "")).split("/")[-1]
    service_order = (
        prefs.get("Sets", {})
        .get(current, {})
        .get("Network", {})
        .get("Global", {})
        .get("IPv4", {})
        .get("ServiceOrder", [])
    )
    services = prefs.get("NetworkServices", {})
    selected = []
    for service_id in service_order + list(services.keys()):
        service = services.get(service_id, {})
        if service_id not in selected and is_dns_service_candidate(service, settings):
            selected.append(service_id)
    if not selected:
        raise RuntimeError("could not find Wi-Fi DNS services")

    changed = False
    desired = {"ServerAddresses": [server_ip] + (UPSTREAMS if settings.get(PREFS_FALLBACK_KEY, True) else [])}
    for service_id in selected:
        if services[service_id].get("DNS") != desired:
            services[service_id]["DNS"] = desired
            changed = True
    if settings.get(PREFS_PRIORITIZE_PROFILES_KEY, False) and service_order:
        non_vpn_dns = [sid for sid in service_order if sid in services and services[sid].get("DNS") and not is_vpn_service(services[sid])]
        vpn = [sid for sid in service_order if sid in services and is_vpn_service(services[sid])]
        rest = [sid for sid in service_order if sid not in non_vpn_dns and sid not in vpn]
        new_order = non_vpn_dns + rest + vpn
        current = str(prefs.get("CurrentSet", "")).split("/")[-1]
        ipv4 = prefs.get("Sets", {}).get(current, {}).get("Network", {}).get("Global", {}).get("IPv4", {})
        if new_order != service_order and isinstance(ipv4, dict):
            ipv4["ServiceOrder"] = new_order
            changed = True
    if not changed:
        log("DNS enforcement already points %d service(s) to %s" % (len(selected), server_ip))
        return server_ip, False
    tmp = PREFERENCES + ".etchosts17tmp"
    with open(tmp, "wb") as handle:
        plistlib.dump(prefs, handle, fmt=plistlib.FMT_BINARY)
    os.chown(tmp, 0, 0)
    os.chmod(tmp, 0o644)
    os.replace(tmp, PREFERENCES)
    log("configured %d Wi-Fi/VPN DNS service(s) -> %s" % (len(selected), server_ip))
    return server_ip, True


def restore_dns_from_backup():
    if not os.path.exists(PREFERENCES_BACKUP):
        return False
    shutil.copy2(PREFERENCES_BACKUP, PREFERENCES)
    os.chown(PREFERENCES, 0, 0)
    os.chmod(PREFERENCES, 0o644)
    log("restored SystemConfiguration DNS preferences from backup")
    return True


def reload_resolver():
    commands = [
        ["/usr/bin/launchctl", "kickstart", "-k", "user/501/com.apple.configd"],
        ["/usr/bin/dscacheutil", "-flushcache"],
        ["/usr/bin/killall", "-HUP", "mDNSResponder"],
        ["/usr/bin/killall", "-9", "mDNSResponder"],
    ]
    for command in commands:
        try:
            subprocess.run(command, stdout=subprocess.DEVNULL, stderr=subprocess.DEVNULL, timeout=8)
        except Exception as exc:
            log("reload command failed %s: %s" % (" ".join(command), exc))


def install_loopback_aliases():
    for address in DNS_ALIASES:
        try:
            subprocess.run(
                ["/usr/sbin/ifconfig", "lo0", "alias", address, "255.255.255.255"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=5,
            )
            log("ensured lo0 DNS alias %s" % address)
        except Exception as exc:
            log("could not add lo0 alias %s: %s" % (address, exc))
    for address in DNS_ALIASES_V6:
        try:
            subprocess.run(
                ["/usr/sbin/ifconfig", "lo0", "inet6", "alias", address, "prefixlen", "128"],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=5,
            )
            log("ensured lo0 IPv6 DNS alias %s" % address)
        except Exception as exc:
            log("could not add lo0 IPv6 alias %s: %s" % (address, exc))


def remove_loopback_aliases():
    for address in DNS_ALIASES:
        try:
            subprocess.run(
                ["/usr/sbin/ifconfig", "lo0", "-alias", address],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=5,
            )
        except Exception:
            pass
    for address in DNS_ALIASES_V6:
        try:
            subprocess.run(
                ["/usr/sbin/ifconfig", "lo0", "inet6", "-alias", address],
                stdout=subprocess.DEVNULL,
                stderr=subprocess.DEVNULL,
                timeout=5,
            )
        except Exception:
            pass


def encode_name(name):
    out = b""
    for label in name.rstrip(".").split("."):
        raw = label.encode("ascii", "ignore")
        out += bytes([len(raw)]) + raw
    return out + b"\0"


def decode_name(packet, offset):
    labels = []
    jumped = False
    next_offset = offset
    seen = set()
    while offset < len(packet):
        if offset in seen:
            raise ValueError("DNS compression loop")
        seen.add(offset)
        length = packet[offset]
        if length & 0xC0:
            if offset + 1 >= len(packet):
                raise ValueError("truncated DNS pointer")
            pointer = ((length & 0x3F) << 8) | packet[offset + 1]
            if not jumped:
                next_offset = offset + 2
            offset = pointer
            jumped = True
            continue
        offset += 1
        if length == 0:
            break
        if offset + length > len(packet):
            raise ValueError("truncated DNS label")
        labels.append(packet[offset:offset + length].decode("ascii", "ignore"))
        offset += length
    return ".".join(labels).rstrip(".").lower(), next_offset if jumped else offset


def cname_answers(packet):
    if len(packet) < 12:
        return []
    _txid, _flags, qd, an, _ns, _ar = struct.unpack("!HHHHHH", packet[:12])
    offset = 12
    for _ in range(qd):
        _name, offset = decode_name(packet, offset)
        offset += 4
    cnames = []
    for _ in range(an):
        _name, offset = decode_name(packet, offset)
        if offset + 10 > len(packet):
            break
        rtype, _rclass, _ttl, rdlen = struct.unpack("!HHIH", packet[offset:offset + 10])
        offset += 10
        rdata_offset = offset
        offset += rdlen
        if rtype == 5:
            try:
                cname, _ = decode_name(packet, rdata_offset)
                if cname:
                    cnames.append(cname)
            except Exception:
                pass
    return cnames


def query_cnames_for_type(name, upstreams, qtype):
    packet = struct.pack("!HHHHHH", int(time.time() * 1000) & 0xFFFF, 0x0100, 1, 0, 0, 0)
    packet += encode_name(name) + struct.pack("!HH", qtype, 1)
    response = forward(packet, upstreams)
    if not response:
        return []
    return cname_answers(response)


def query_cnames(name, upstreams):
    cnames = query_cnames_for_type(name, upstreams, 5)
    if not cnames:
        cnames = query_cnames_for_type(name, upstreams, 1)
    return cnames


def expand_hosts_with_cnames(hosts):
    expanded = dict(hosts)
    for name, addresses in list(hosts.items()):
        current = name
        seen = {name}
        for _ in range(4):
            cnames = [c for c in query_cnames(current, UPSTREAMS) if c and c not in seen]
            if not cnames:
                break
            current = cnames[-1]
            seen.add(current)
            if current not in expanded:
                expanded[current] = list(addresses)
                log("CNAME override alias %s -> %s" % (current, name))
    return expanded


def parse_question(packet):
    if len(packet) < 12:
        return None
    offset = 12
    labels = []
    while offset < len(packet):
        length = packet[offset]
        offset += 1
        if length == 0:
            break
        if length & 0xC0 or offset + length > len(packet):
            return None
        labels.append(packet[offset:offset + length].decode("ascii", "ignore"))
        offset += length
    if offset + 4 > len(packet):
        return None
    qtype, qclass = struct.unpack("!HH", packet[offset:offset + 4])
    return ".".join(labels).lower(), qtype, qclass, offset + 4


def empty_response(packet, question_end):
    return packet[:2] + b"\x81\x80\x00\x01\x00\x00\x00\x00\x00\x00" + packet[12:question_end]


def answer_response(packet, question_end, address):
    rtype = 1 if address.version == 4 else 28
    answer = (
        b"\xc0\x0c"
        + struct.pack("!HHI", rtype, 1, 60)
        + struct.pack("!H", len(address.packed))
        + address.packed
    )
    return packet[:2] + b"\x81\x80\x00\x01\x00\x01\x00\x00\x00\x00" + packet[12:question_end] + answer


def forward(packet, upstreams):
    for upstream in upstreams:
        sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
        sock.settimeout(2)
        try:
            sock.sendto(packet, (upstream, 53))
            response, _ = sock.recvfrom(4096)
            return response
        except OSError:
            pass
        finally:
            sock.close()
    return None


def daemon():
    ensure_storage()
    try:
        sync_hosts()
    except Exception as exc:
        log("initial host sync failed: %s" % exc)
    sock = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    sock.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    sock.bind(("0.0.0.0", 53))
    sockets = [sock]
    sock6 = None
    try:
        sock6 = socket.socket(socket.AF_INET6, socket.SOCK_DGRAM)
        sock6.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
        sock6.setsockopt(socket.IPPROTO_IPV6, socket.IPV6_V6ONLY, 1)
        sock6.bind(("::", 53))
        sockets.append(sock6)
    except OSError as exc:
        log("IPv6 DNS listener unavailable: %s" % exc)
    control = socket.socket(socket.AF_INET, socket.SOCK_DGRAM)
    control.setsockopt(socket.SOL_SOCKET, socket.SO_REUSEADDR, 1)
    control.bind(("127.0.0.1", CONTROL_PORT))
    log("EtcHosts17 DNS daemon listening on 0.0.0.0:53")
    if sock6:
        log("EtcHosts17 DNS daemon listening on [::]:53")
    log("EtcHosts17 control listening on 127.0.0.1:%d" % CONTROL_PORT)
    last_mtime = None
    hosts = {}
    last_enforce = 0
    while True:
        try:
            now = time.time()
            settings = read_settings()
            if now - last_enforce >= ENFORCE_INTERVAL:
                try:
                    if settings.get(PREFS_ENABLED_KEY, True):
                        if settings.get(PREFS_OVERRIDE_VPN_KEY, True):
                            install_loopback_aliases()
                        else:
                            remove_loopback_aliases()
                        _ip, changed = configure_dns(settings=settings)
                    else:
                        remove_loopback_aliases()
                        changed = restore_dns_from_backup()
                    if changed:
                        reload_resolver()
                except Exception as exc:
                    log("DNS enforcement failed: %s" % exc)
                last_enforce = now
            mtimes = tuple((p, os.stat(p).st_mtime) for p in (DAEMON_HOSTS, ROOTFS_EXTRA, JBROOT_EXTRA, ROOTFS_PREFS, JBROOT_PREFS) if os.path.exists(p))
            if mtimes != last_mtime:
                hosts = expand_hosts_with_cnames(load_hosts()) if settings.get(PREFS_ENABLED_KEY, True) else {}
                last_mtime = mtimes
                log("loaded %d override host(s)" % len(hosts))
            ready, _, _ = select.select(sockets + [control], [], [], 30)
            if not ready:
                continue
            if control in ready:
                payload, _client = control.recvfrom(65535)
                if payload.startswith(CONTROL_MAGIC):
                    text = payload[len(CONTROL_MAGIC):].decode("utf-8", "ignore")
                    try:
                        text = validated_hosts_text(text)
                    except ValueError as exc:
                        log("rejected invalid control update: %s" % exc)
                        continue
                    write_hosts_plist(ROOTFS_PREFS, text)
                    write_hosts_plist(JBROOT_PREFS, text)
                    write_text(DAEMON_HOSTS, text)
                    settings = read_settings()
                    hosts = expand_hosts_with_cnames(parse_hosts_text(text)) if settings.get(PREFS_ENABLED_KEY, True) else {}
                    last_mtime = None
                    log("control update loaded %d override host(s)" % len(hosts))
                continue
            query_sock = sock6 if sock6 in ready else sock
            packet, client = query_sock.recvfrom(4096)
            parsed = parse_question(packet)
            if not parsed:
                continue
            name, qtype, _qclass, question_end = parsed
            addresses = hosts.get(name)
            if addresses:
                match = None
                for address in addresses:
                    if (qtype == 1 and address.version == 4) or (qtype == 28 and address.version == 6):
                        match = address
                        break
                if match:
                    query_sock.sendto(answer_response(packet, question_end, match), client)
                    log("override %s -> %s" % (name, match))
                else:
                    query_sock.sendto(empty_response(packet, question_end), client)
                    log("suppress %s qtype %d" % (name, qtype))
                continue
            response = forward(packet, UPSTREAMS)
            if response:
                query_sock.sendto(response, client)
        except Exception as exc:
            log("daemon request error: %s" % exc)


def apply():
    sync_hosts()
    settings = read_settings()
    if not settings.get(PREFS_ENABLED_KEY, True):
        remove_loopback_aliases()
        changed = restore_dns_from_backup()
        if changed:
            reload_resolver()
        log("apply complete with tweak disabled")
        return
    if settings.get(PREFS_OVERRIDE_VPN_KEY, True):
        install_loopback_aliases()
    else:
        remove_loopback_aliases()
    ip, changed = configure_dns(settings=settings)
    reload_resolver()
    log("apply complete with DNS %s" % ip)


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("mode", choices=["apply", "daemon", "sync", "unalias"], nargs="?", default="apply")
    args = parser.parse_args()
    if args.mode == "daemon":
        daemon()
    elif args.mode == "sync":
        sync_hosts()
    elif args.mode == "unalias":
        remove_loopback_aliases()
    else:
        apply()


if __name__ == "__main__":
    main()
